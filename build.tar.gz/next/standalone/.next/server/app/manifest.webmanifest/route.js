var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/[root-of-the-server]__314bd883._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_manifest_webmanifest_route_actions_1bff3fca.js")
R.m(37648)
module.exports=R.m(37648).exports
