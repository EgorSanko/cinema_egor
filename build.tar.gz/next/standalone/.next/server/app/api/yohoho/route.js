var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/yohoho/route.js")
R.c("server/chunks/[root-of-the-server]__3ef79707._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_yohoho_route_actions_279c7ce9.js")
R.m(18032)
module.exports=R.m(18032).exports
