var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/stream/route.js")
R.c("server/chunks/[root-of-the-server]__3a5fc215._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_stream_route_actions_527001fa.js")
R.m(99203)
module.exports=R.m(99203).exports
