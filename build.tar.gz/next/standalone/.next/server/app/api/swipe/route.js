var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/swipe/route.js")
R.c("server/chunks/[root-of-the-server]__de069c9c._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_b612e582.js")
R.c("server/chunks/_next-internal_server_app_api_swipe_route_actions_8467a796.js")
R.m(7837)
module.exports=R.m(7837).exports
