var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tmdb-proxy/route.js")
R.c("server/chunks/[root-of-the-server]__2510365b._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_tmdb-proxy_route_actions_4fac1bca.js")
R.m(49647)
module.exports=R.m(49647).exports
