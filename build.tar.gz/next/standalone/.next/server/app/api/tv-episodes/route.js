var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tv-episodes/route.js")
R.c("server/chunks/[root-of-the-server]__9517dc5c._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_tv-episodes_route_actions_f0a75a04.js")
R.m(88630)
module.exports=R.m(88630).exports
