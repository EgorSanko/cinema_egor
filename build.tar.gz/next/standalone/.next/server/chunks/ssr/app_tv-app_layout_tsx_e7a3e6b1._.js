module.exports=[94265,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c,"metadata",0,{title:"Кинотеатр Егора — TV",description:"Смотрите фильмы на большом экране с пульта"}])}];

//# sourceMappingURL=app_tv-app_layout_tsx_e7a3e6b1._.js.map