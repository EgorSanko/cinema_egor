module.exports=[834,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stream_route_actions_527001fa.js.map