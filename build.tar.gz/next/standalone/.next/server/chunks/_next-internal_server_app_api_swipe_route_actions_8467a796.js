module.exports=[62996,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_swipe_route_actions_8467a796.js.map