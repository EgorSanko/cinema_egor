module.exports=[81649,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_yohoho_route_actions_279c7ce9.js.map