module.exports=[51313,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sync_route_actions_78e25bf5.js.map