module.exports=[19955,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_tmdb-proxy_route_actions_4fac1bca.js.map